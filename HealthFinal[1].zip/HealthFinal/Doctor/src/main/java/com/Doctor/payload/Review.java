package com.Doctor.payload;

import lombok.Data;

@Data
public class Review {
    private String content;
    private double rating;
}

package com.Doctor.payload;

import lombok.Data;

@Data

public class Docterdeletedto {
    private String DoctorId;
    private String Email;
    private String Password;
}

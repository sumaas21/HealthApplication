package com.Doctor.payload;

import lombok.Data;

@Data

public class Reviewdto {
    private String content;
    private double rating;
}

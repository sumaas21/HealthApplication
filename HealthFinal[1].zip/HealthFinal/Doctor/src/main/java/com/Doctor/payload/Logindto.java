package com.Doctor.payload;

import lombok.Data;

@Data
public class Logindto {


    private String usernameOremail;

    private String password;
}

package com.Doctor.payload;

import lombok.Data;

@Data
public class Reviewedusers {
    private String name;

    private String email;
}

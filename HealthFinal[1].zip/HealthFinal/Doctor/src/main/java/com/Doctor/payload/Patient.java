package com.Doctor.payload;

public class Patient {

}

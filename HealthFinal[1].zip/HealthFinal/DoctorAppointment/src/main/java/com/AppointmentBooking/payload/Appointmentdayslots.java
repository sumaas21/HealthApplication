package com.AppointmentBooking.payload;

public enum Appointmentdayslots {
    MORNING,AFTETRNOON  ,EVENING;
}

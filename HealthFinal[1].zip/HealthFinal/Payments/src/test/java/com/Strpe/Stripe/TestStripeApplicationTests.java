package com.stripe1_nobroker1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestStripeApplicationTests {

	@Test
	void contextLoads() {
	}

}

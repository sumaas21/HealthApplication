package com.insurance.services;

import com.insurance.entity.Gender;
import com.insurance.entity.InsuranceDetails;
import com.insurance.entity.InsuranceType;
import com.insurance.entity.User;
import com.insurance.payload.Insuranceview;
import com.insurance.payload.UserDto;
import com.insurance.repository.InsuranceDetailsRepository;
import com.insurance.repository.InsuranceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class InsuranceServicesIMPL implements InsuranceServices {
    @Autowired
    private InsuranceRepository repository;

    @Autowired
    InsuranceDetailsRepository detailsRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;



    static UserDto mapToDto(User user){
        UserDto dto = new UserDto();
        dto.setUserId(user.getUserId());
        dto.setUserName(user.getUserName());
        dto.setFirstName(user.getFirstName());
        dto.setLastName(user.getLastName());
        dto.setBirthDate(user.getBirthDate());
        dto.setGender(user.getGender().name());
        dto.setEmail(user.getEmail());
        dto.setMobileNo(user.getMobileNo());
        dto.setInsuranceDetails(user.getInsuranceDetails());
        dto.setInsuranceType(String.valueOf(user.getInsuranceDetails().getInsuranceType()));
        return dto;
    }

    public ResponseEntity<String> createInsuranceOfUser(UserDto userDto,String userI) {

        User user = new User();
        long userId = Long.parseLong(userI);
        long insuranceId = Math.abs(UUID.randomUUID().getMostSignificantBits());
        user.setUserId(userId);
        user.setUserName(userDto.getUserName());
        user.setFirstName(userDto.getFirstName());
        user.setLastName(userDto.getLastName());
        user.setGender(Gender.valueOf(userDto.getGender().toUpperCase()));
        user.setBirthDate(userDto.getBirthDate());
        user.setEmail(userDto.getEmail());
        user.setMobileNo(userDto.getMobileNo());
        user.setPassword(passwordEncoder.encode(userDto.getPassword()));
        InsuranceDetails insurance = new InsuranceDetails();
        insurance.setInsuranceId(insuranceId);
        insurance.setUserId(userId);
        insurance.setCreationDate(Date.valueOf(LocalDate.now()));
        // Calculates the age based on the provided birth_date & sets expiryDate of policy according to insurance type
        LocalDate currentDate = LocalDate.now();
        LocalDate birthDate = userDto.getBirthDate().toLocalDate();
        Period calculation = Period.between(birthDate, currentDate);
        int age = calculation.getYears();
        if (userDto.getInsuranceType().equals("LIFE_INSURANCE")){
            if (age < 30){
                LocalDate expiryDate = currentDate.plusYears(30 - age);
                insurance.setExpiryDate(Date.valueOf(expiryDate));
                insurance.setInsuranceDetailsForType(InsuranceType.LIFE_INSURANCE);
            } else if (age > 30) {
                return new ResponseEntity<>("you are not applicable for 'LIFE_INSURANCE' Insurance Policy please choose another policy ", HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } else if (userDto.getInsuranceType().equals("LONG_TERM_LIFE_INSURANCE")) {
            LocalDate expiryDate = currentDate.plusYears(100 - age);
            insurance.setExpiryDate(Date.valueOf(expiryDate));
            insurance.setInsuranceDetailsForType(InsuranceType.LONG_TERM_LIFE_INSURANCE);
        }
        user.setInsuranceDetails(insurance);
        repository.save(user);
        return ResponseEntity.status(HttpStatus.CREATED).body("Insurance Created");
    }

    @Override
    public ResponseEntity<String> upgradeInsuranceToLong_Term(UserDto userDto) {
        String email = userDto.getEmail();
        String userName = userDto.getUserName();
        long mobileNo = userDto.getMobileNo();
        User user = repository.findByEmailOrUserNameOrMobileNo(email, userName, mobileNo);
        if (user != null) {
            Long userId = user.getUserId();
            InsuranceDetails insuranceDetails = detailsRepository.findByUserId(userId);
            if (insuranceDetails != null){
                if (insuranceDetails.getInsuranceType().equals(InsuranceType.LIFE_INSURANCE)){
                    LocalDate currentDate = LocalDate.now();
                    LocalDate birthDate = user.getBirthDate().toLocalDate();
                    Period calculation = Period.between(birthDate, currentDate);
                    int age = calculation.getYears();
                    LocalDate expiryDate = currentDate.plusYears(100 - age);
                    insuranceDetails.setExpiryDate(Date.valueOf(expiryDate));
                    insuranceDetails.setInsuranceDetailsForType(InsuranceType.LONG_TERM_LIFE_INSURANCE);
                    detailsRepository.save(insuranceDetails);
                    return new ResponseEntity<>("policy upgraded ", HttpStatus.OK);
                }else if (insuranceDetails.getInsuranceType().equals(InsuranceType.LONG_TERM_LIFE_INSURANCE)){
                    return new ResponseEntity<>("you already have subscription of higher policy 'invalid request' ", HttpStatus.BAD_REQUEST);
                }
            } else {
                return new ResponseEntity<>("you don't have subscription of any insurance policy", HttpStatus.BAD_REQUEST);
            }
        }
        return new ResponseEntity<>("User not found", HttpStatus.BAD_REQUEST);
    }

    @Override
    public ResponseEntity<String> unsubscribeInsurancePolicy(long userId) {
        Optional<User> userOptional = repository.findById(userId);
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            InsuranceDetails insuranceDetails = user.getInsuranceDetails();
            if (insuranceDetails != null) {
                repository.deleteById(userId);
                return new ResponseEntity<>("Unsubscribed from " + insuranceDetails.getInsuranceType() + " insurance policy",HttpStatus.OK);
            }
            return new ResponseEntity<>("Failed to unsubscribe insurance policy", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity <>("User not found with userId: " + userId, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Override
    public ResponseEntity<List<UserDto>> getAllUsersWithInsuranceDetails() {
        List<User> allusers = repository.findAll();
        return new ResponseEntity<> (allusers.stream().map(InsuranceServicesIMPL::mapToDto).collect(Collectors.toList()),HttpStatus.OK);

    }

    @Override
    public ResponseEntity<?> getInsuranceDetailsOfUserByUserId(long userId) {
        Optional<User> user = repository.findById(userId);
        if (user.isPresent()){
            User userDetails = user.get();
            UserDto userDto = mapToDto(userDetails);
            return new ResponseEntity<>(userDto, HttpStatus.OK);
        }
        return new ResponseEntity<>("user not found with id : "+userId, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Override
    public ResponseEntity<?> insuranceView(String userId) {
        Insuranceview insuranceview = new Insuranceview();
        insuranceview.setMyActivities("YOUR ACTIVITIES   :"+insuranceview.getMyActivities()+"/"+userId);
        insuranceview.setSubscribe("SUBSCRIBE            :"+insuranceview.getSubscribe());
        insuranceview.setUpgrade("UPGRADE                :"+insuranceview.getUpgrade());
        insuranceview.setUnsubscribe("UNSUBSCRIBE         :"+insuranceview.getUnsubscribe());
        return new ResponseEntity<>(insuranceview,HttpStatus.OK);
    }


}

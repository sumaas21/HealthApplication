package com.insurance.entity;

public enum InsuranceType {
    LIFE_INSURANCE,
    LONG_TERM_LIFE_INSURANCE;
}

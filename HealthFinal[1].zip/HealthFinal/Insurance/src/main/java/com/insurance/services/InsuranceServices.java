package com.insurance.services;

import com.insurance.payload.UserDto;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface InsuranceServices {
    ResponseEntity<String> createInsuranceOfUser(UserDto userDto,String userId);

    ResponseEntity<String> upgradeInsuranceToLong_Term(UserDto userDto);

    ResponseEntity<String> unsubscribeInsurancePolicy(long userId);

    ResponseEntity<List<UserDto>> getAllUsersWithInsuranceDetails();

    ResponseEntity<?> getInsuranceDetailsOfUserByUserId(long userId);
    ResponseEntity<?> insuranceView(String userId);
}

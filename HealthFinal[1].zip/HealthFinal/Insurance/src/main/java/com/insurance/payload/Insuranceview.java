package com.insurance.payload;

import lombok.Data;
import org.apache.tomcat.util.http.parser.Upgrade;
@Data
public class Insuranceview {

    public String Subscribe ="http://localhost:8087/insurance/subscribe";
    public String Upgrade ="http://localhost:8087/insurance/upgrade";
    public String Unsubscribe ="http://localhost:8087/insurance/unsubscribe/{userId}";
    public String MyActivities ="http://localhost:8087/insurance/getmy";
}

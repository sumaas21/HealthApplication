package com.insurance.controller;

import com.insurance.entity.User;
import com.insurance.payload.UserDto;
import com.insurance.services.InsuranceServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/insurance")
public class InsuranceController {

    @Autowired
    private InsuranceServices services;

    //http:localhost:8087/insurance/InsuranceHome/{userId}
    @GetMapping("InsuranceHome/{userId}")
    public ResponseEntity<?> Insuranceview(@PathVariable  String userId){
       return services.insuranceView(userId);
    }

    @PostMapping("/subscribe/{userId}")
    public ResponseEntity<String> createInsuranceOfUser(@RequestBody UserDto userDto,@PathVariable String userId){
        return services.createInsuranceOfUser(userDto,userId);

    }

    @PutMapping("/upgrade")
    public ResponseEntity<String> upgradeInsuranceToLong_Term(@RequestBody UserDto userDto){
        return services.upgradeInsuranceToLong_Term(userDto);
    }

    @DeleteMapping("/unsubscribe/{userId}")
    public ResponseEntity<String> unsubscribeInsurancePolicy(@PathVariable long userId){
        return services.unsubscribeInsurancePolicy(userId);
    }

    //only for admin
    @GetMapping("/all")
    public ResponseEntity<List<UserDto>> getAllUserWithInsuranceDetails(){
        return services.getAllUsersWithInsuranceDetails();
    }
    @GetMapping("getmy/{userId}")
    public ResponseEntity<?> getInsuranceDetailsOfUserBYUseId(@PathVariable long userId){
        return services.getInsuranceDetailsOfUserByUserId(userId);
    }



}

package com.insurance.entity;

public enum Gender {
    MALE,
    FEMALE;

}

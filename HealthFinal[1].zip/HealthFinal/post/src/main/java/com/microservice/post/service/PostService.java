package com.microservice.post.service;

import com.microservice.post.config.RestTemplateConfig;
import com.microservice.post.entity.Post;
import com.microservice.post.payload.Comment;
import com.microservice.post.payload.PostDto;
import com.microservice.post.repository.PostRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class PostService {
    @Autowired
    private PostRepository postRepository;
    @Autowired
    private RestTemplateConfig restTemplate;

    public void savePost(String AuthorUsername, Post post) {
        String postId = UUID.randomUUID().toString();
        Date date = new Date();
        String datetime = date.toString();
        post.setDatetime(datetime);
        post.setId(postId);
        post.setAuthor(AuthorUsername);
        Post savedPost = postRepository.save(post);
    }
    public Post findPostById(String postId) {
        Post post = postRepository.findById(postId).get();
        return post;
    }
    public PostDto getPostWithComments(String postId) {
        Post post = postRepository.findById(postId).get();
        Comment[] comments = restTemplate.getRestTemplate().getForObject("http://localhost:8082/api/comments/" + postId, Comment[].class);
        double totalrating = 0;
        int count = 0;
        for (Comment comment1 : comments) {
            totalrating = totalrating + comment1.getRating();
            count++;
        }
        double avgrating = 0;
        avgrating = totalrating / count;
        post.setRating(avgrating);
        PostDto dto = new PostDto();
        dto.setRating(avgrating);
        dto.setPostId(post.getId());
        dto.setTitle(post.getTitle());
        dto.setDescription(post.getDescription());
        dto.setContent(post.getContent());
        dto.setCommentList(Arrays.asList(comments));
        return dto;
    }
    public PostDto recent(String postId) {
        Post post = postRepository.findById(postId).get();
        Comment[] comments = restTemplate.getRestTemplate().getForObject("http://localhost:8082/api/comments/recentcomments/" + postId, Comment[].class);
        double totalrating = 0;
        int count = 0;
        for (Comment comment1 : comments) {
            totalrating = totalrating + comment1.getRating();
            count++;
        }
        double avgrating = 0;
        avgrating = totalrating / count;
        post.setRating(avgrating);
        PostDto dto = new PostDto();
        dto.setRating(avgrating);
        dto.setPostId(post.getId());
        dto.setTitle(post.getTitle());
        dto.setDescription(post.getDescription());
        dto.setContent(post.getContent());
        dto.setCommentList(Arrays.asList(comments));
        return dto;
    }
    public PostDto ratingsort(String postId) {
        Post post = postRepository.findById(postId).get();
        Comment[] comments = restTemplate.getRestTemplate().getForObject("http://COMMENT-SERVICE/api/comments/ratingsortcomments/" + postId, Comment[].class);
        double totalrating = 0;
        int count = 0;
        for (Comment comment1 : comments) {
            totalrating = totalrating + comment1.getRating();
            count++;
        }
        double avgrating = 0;
        avgrating = totalrating / count;
        post.setRating(avgrating);
        PostDto dto = new PostDto();
        dto.setRating(avgrating);
        dto.setPostId(post.getId());
        dto.setTitle(post.getTitle());
        dto.setDescription(post.getDescription());
        dto.setContent(post.getContent());
        dto.setCommentList(Arrays.asList(comments));
        return dto;
    }

    public Set<Post> getallposts() {
        List<Post> all = postRepository.findAll();
        List<Post> showost =all.stream().collect(Collectors.toList());
        for (Post returnd : all) {
            Comment[] gotcomments = restTemplate.getRestTemplate().getForObject("http://localhost:8084/api/comments/byid/"+returnd.getId(), Comment[].class);
            List<Comment> fetchcomment = Arrays.stream(gotcomments).collect(Collectors.toList());
            double totalrating = 0.0;
            int count = 0;
            for (Comment adddavgrating : gotcomments) {
                totalrating = totalrating + adddavgrating.getRating();
                count++;
                if (fetchcomment.indexOf(adddavgrating) == fetchcomment.size() - 1) {
                    double avgrating = 0;
                    avgrating = totalrating / count;
                    returnd.setRating(avgrating);
                    Post save = postRepository.save(returnd);
                    showost.add(save);
                }
            }
        }
        List<Post> showpopst =  new ArrayList<>(showost);
        Set<Post> returnedpost = new HashSet<>(showpopst);
        return returnedpost;
    }
    public Set<Post> commentFallback(){
        List<Post> all = postRepository.findAll();
        Set<Post> returnedpost = all.stream().collect(Collectors.toSet());
        return returnedpost;
    }


}

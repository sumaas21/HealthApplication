package com.microservice.post.entity;

import com.microservice.post.payload.Comment;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor

@Document(collection = "BLOGPOST")
public class Post {
    @Id
    private String id;
    private String datetime;
    private String author;
    private String title;
    private String description;
    private String content;
    private double rating;

private String comments;



}
